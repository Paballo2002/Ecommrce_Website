﻿using HairoScope.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HairoScope
{
    public partial class Cart : System.Web.UI.Page
    {
        IhairoscropeClient sr = new IhairoscropeClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            //DynamicallyDisplayProducts();
        }

        //private String GenerateProducts(Product prod)
        //{
        //    if (prod != null)
        //    {
        //        String display = "";

        //        display += "<div class=\"col-lg-4 col-md-6 text-center strawberry\">";
        //        display += "<div class=\"single-product-item\">";
        //        display += "<div class=\"product-image\">";
        //        display += "<a href='single-product.aspx?singleProductID=" + prod.Id + "'><img src=" + prod.ProductImage + " alt=\"\" width=\"300\" height=\"300\"></a>";
        //        display += "</div>";
        //        display += "<h3>" + prod.ProductName + "</h3>";
        //        display += "<p class=\"product-price\"><span>Per Kg</span>R" + prod.ProductPrice + "</p>";
        //        display += "<a href='cart.aspx?addtocartID=" + prod.Id + "' class=\"cart-btn\"><i class=\"fas fa-shopping-cart\"></i> Add to Cart</a>";
        //        display += "<h1> </h1>";
        //        display += "<a href='wishlist.aspx?addtowishlistID=" + prod.Id + "' class=\"cart-btn\"><i class=\"fas fa-shopping-cart\"></i> Add to Wishlist</a>";
        //        display += "</div>";
        //        display += "</div>";

        //        return display;
        //    }
        //    else
        //    {
        //        dynamicallyPopulateFruits.InnerHtml = "Products are out of stock";
        //        return null;
        //    }
        //}

        //private void DynamicallyDisplayProducts()
        //{
        //    var productsList = sr.GetProductList();
        //    if (productsList != null)
        //    {
        //        String display = "";
        //        foreach (Product prod in productsList)
        //        {
        //            display += GenerateProducts(prod);
        //        }
        //        dynamicallyPopulateFruits.InnerHtml = display;
        //    }
        //    else
        //    {
        //        dynamicallyPopulateFruits.InnerHtml = "No Products in the database";
        //    }
        //}

        //protected void FilterProducts_Click(object sender, EventArgs e)
        //{
        //    LinkButton linkbutton = (LinkButton)sender;
        //    String typeID = linkbutton.ID;

        //    if (typeID.Equals("All"))
        //    {
        //        DynamicallyDisplayProducts();
        //    }
        //    else if (typeID.Equals("Strawberry") || typeID.Equals("Lemon") || typeID.Equals("Grapes"))
        //    {
        //        var getprodbyname = sr.GetProductByName(typeID);
        //        if (getprodbyname != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodbyname)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("firstprice"))
        //    {
        //        var getprodByPrice = sr.GetProductByPrice(0, 30);
        //        if (getprodByPrice != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodByPrice)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("secondprice"))
        //    {
        //        var getprodByPrice = sr.GetProductByPrice(30, 60);
        //        if (getprodByPrice != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodByPrice)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("Fruit"))
        //    {
        //        var getprodType = sr.GetProductByType(typeID);
        //        if (getprodType != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodType)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("Medium") || typeID.Equals("Large"))
        //    {
        //        var getprodType = sr.GetProductBySize(typeID);
        //        if (getprodType != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodType)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //}
    }
}