﻿using HairoScope.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HairoScope
{
    public partial class Product : System.Web.UI.Page
    {
        IhairoscropeClient sr = new IhairoscropeClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            DynamicallyDisplayProducts();
        }

        private String GenerateProducts(ServiceReference1.Product prod)
        {
            if (prod != null)
            {
                String display = "";

                display += "<div class='col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item bob'>";
                display += "<div class='block2'>";
                display += "<div class='block2-pic hov-img0'>";
                display += "<a href='singleProduct.aspx?SINGLEPRODID="+prod.P_Id+"'><img src='" + prod.P_Img+"' alt='IMG-PRODUCT' width='200' height='210'></a>";
                //display += "<a href = '#' class='block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1'>Quick View</a>";
                display += "</div>";
                display += "<div class='block2-txt flex-w flex-t p-t-14'>";
                display += "<div class='block2-txt-child1 flex-col-l'>";
                display += "<a href = 'product-detail.html' class='stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6'>"+prod.P_Name+"</a>";
                display += "<span class='stext-105 cl3'>R"+prod.P_Price+"</span>";
                display += "</div>";
                display += "<div class='block2-txt-child2 flex-r p-t-3'>";
                display += "<a href = '#' class='btn-addwish-b2 dis-block pos-relative js-addwish-b2'>";
                display += "<img class='icon-heart1 dis-block trans-04' src='images/icons/icon-heart-01.png' alt='ICON'>";
                display += "<img class='icon-heart2 dis-block trans-04 ab-t-l' src='images/icons/icon-heart-02.png' alt='ICON'>";
                display += "</a>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                display += "</div>";

                return display;
            }
            else
            {
                hairs.InnerHtml = "Products are out of stock";
                return null;
            }
        }

        private void DynamicallyDisplayProducts()
        {
            var productsList = sr.GetProductList();
            if (productsList != null)
            {
                String display = "";
                foreach (ServiceReference1.Product prod in productsList)
                {
                    display += GenerateProducts(prod);
                }
                hairs.InnerHtml = display;
            }
            else
            {
                hairs.InnerHtml = "No Products in the database";
            }
        }

        //protected void FilterProducts_Click(object sender, EventArgs e)
        //{
        //    LinkButton linkbutton = (LinkButton)sender;
        //    String typeID = linkbutton.ID;

        //    if (typeID.Equals("All"))
        //    {
        //        DynamicallyDisplayProducts();
        //    }
        //    else if (typeID.Equals("Strawberry") || typeID.Equals("Lemon") || typeID.Equals("Grapes"))
        //    {
        //        var getprodbyname = sr.GetProductByName(typeID);
        //        if (getprodbyname != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodbyname)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("firstprice"))
        //    {
        //        var getprodByPrice = sr.GetProductByPrice(0, 30);
        //        if (getprodByPrice != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodByPrice)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("secondprice"))
        //    {
        //        var getprodByPrice = sr.GetProductByPrice(30, 60);
        //        if (getprodByPrice != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodByPrice)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("Fruit"))
        //    {
        //        var getprodType = sr.GetProductByType(typeID);
        //        if (getprodType != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodType)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //    else if (typeID.Equals("Medium") || typeID.Equals("Large"))
        //    {
        //        var getprodType = sr.GetProductBySize(typeID);
        //        if (getprodType != null)
        //        {
        //            string display = "";
        //            foreach (Product prd in getprodType)
        //            {

        //                display += GenerateProducts(prd);
        //            }
        //            dynamicallyPopulateFruits.InnerHtml = display;
        //        }
        //        else
        //        {
        //            dynamicallyPopulateFruits.InnerHtml = "Products out of stock";
        //        }
        //    }
        //}
    }
}