﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Hairoscope_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        UserRegistration Register(string name, string surname, string email, string password, string type, string managerIDnum , DateTime dob , string managerContact);

        [OperationContract]
        int userExistence(string email);

        [OperationContract]
        UserRegistration Login(string email, string password);

        [OperationContract]
        List<Product> GetProductList(); 

        [OperationContract]
        Product GetSignleProduct(int prodid);

        [OperationContract]
        List<Product> GetProductByType(string prodtype);

        [OperationContract]
        List<Product> GetProductByColour(string prodcolour);

        [OperationContract]
        List<Product> GetProductByName(string prodname);

        [OperationContract]
        List<Product> GetProductByCategory(string prodcat);

        [OperationContract]
        List<Product> GetProductByPrice(decimal minprice, decimal maxprice);

        [OperationContract]
        List<Product> GetProductByDate(int proddate);

        [OperationContract]
        List<Product> GetProductBySize(String size);

        [OperationContract]
        Cart Addtocart(int userid, int productid, double ProdPrice, string prodImage, int quantity, DateTime dateaddedce, double totalPrice, string prodname, string prodDescription);

        [OperationContract]
        List<Cart> GetAddedItems(int userID);

        [OperationContract]
        bool AddtowishList(int productId, string prodname, string prodImage, double prodPrice, string prodDescription, DateTime date);

        [OperationContract]
        List<WishLIst> GetWishListItems();

        [OperationContract]
        bool RemoveItemonwishlist(int id);

        [OperationContract]
        bool IncreaseQuantity(int id);

        [OperationContract]
        double TotalPRICE(int userID);

        [OperationContract]
        bool DecreaseQuantity(int id);

        [OperationContract]
        bool RemoveFromCart(int id);

        [OperationContract]
        bool AddProduct(string prodname, string colour, double prodPrice, string prodImage, string prodType, string size, string prodDesc, string category, int stockquantity);

        [OperationContract]
        bool EditProduct(int prodid, string prodname, string colour, double prodPrice, string prodImage, string prodType, string size, DateTime prodDtae, string prodDesc, string category, int stockquantity);

        [OperationContract]
        bool DeleteProduct(int prodID);

        [OperationContract]
        Invoice GenerateInvoice(double prodTotalprice, string username, string userSURNAME, string userContact, string userADDRESS, string userCity, DateTime date, int userid, double vat);

    }
}
